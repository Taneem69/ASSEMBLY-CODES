.MODEL SMALL
.STACK 100H
.DATA
;VARIABLE DECLAIRATION
A DB "HELLO WORLD$" 
B DB "HELLO$" 
NEWLINE DB 0AH,0DH,'$'
NEW DB 10,13,'$'
.CODE
MAIN PROC 
    
    MOV AX,@DATA
    MOV DS, AX 
    
    ;PRINT A
    MOV AH,9  
    LEA DX,A
    INT 21H
    
    ;NEWLINE
    MOV AH,2
    MOV DL,10
    INT 21H
    MOV DL,13
    INT 21H  
       
    ;PRINT B
    MOV AH,9
    LEA DX,B
    INT 21H
    
    ;NEWLINE
    MOV AH,9
    LEA DX,NEW
    INT 21H 
           
    ;PRINT B       
    MOV AH,9 
    LEA DX,B
    INT 21H
    
    ;NEWLINE
    MOV AH,9
    LEA DX,NEW
    INT 21H          

    MOV AH,4CH
    INT 21H
    MAIN ENDP
END MAIN
    
