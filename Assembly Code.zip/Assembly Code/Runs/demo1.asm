.MODEL SMALL
.STACK 100H
.DATA

MSG DB 'HELLO NIGGA$'
A DB 0AH, 0DH, 'ENTER NUMBER 1: $'
B DB 0AH, 0DH, 'ENTER NUMBER 2: $'
C DB 0AH, 0DH, 'YOUR RESULT NIGGA: $'
.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
     
    MOV AH, 9
    LEA DX, MSG
    INT 21H
     
     
    ;INPUT 1 
    MOV AH, 9
    LEA DX, A
    INT 21H
    
    MOV AH, 1
    INT 21H
    MOV BL, AL
    ;......... 
     
     
     
    ;INTPUT 2
    MOV AH, 9
    LEA DX, B
    INT 21H
    
     
    MOV AH, 1
    INT 21H
    MOV CL, AL
    ;.........
    
    
    
    
    ADD BL, CL  ;AFTER ADDING WE GET HEX VALUE
    SUB BL, 30H ;TO GET DECIMAL VALUE FROM HEX VALUE
    
    
    ;OUTPUT
    MOV AH, 9
    LEA DX, C
    INT 21H
    
    
    MOV AH, 2
    MOV DL, BL
    INT 21H
    ;......... 
    
     
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN