.MODEL SMALL
.STACK 100H
.DATA
NEWLINE DB 0AH, 0DH, '$'
.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AH, 1
    INT 21H
    MOV BL, AL
    
    
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
    
    
    MOV AH, 2
    MOV DL, BL
    INT 21H
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN