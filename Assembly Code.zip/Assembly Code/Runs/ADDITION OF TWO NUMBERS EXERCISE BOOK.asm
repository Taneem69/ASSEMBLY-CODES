.MODEL SMALL
.STACK 100H
.DATA                    
    MSG     DB 'THE SUM OF $'
    AND_MSG DB ' AND $'
    IS_MSG  DB ' IS $'

.CODE
MAIN PROC  
    ; 1. ALWAYS INITIALIZE DATA SEGMENT FIRST
    MOV AX, @DATA
    MOV DS, AX
    
    ;INPUT MSG
    MOV AH, 2
    MOV DL, '?'
    INT 21H

    
    ;TAKE 1ST INPUT
    MOV AH, 1
    INT 21H
    SUB AL, 30H
    MOV BL, AL
    
    
    
    ;TAKE SECOND INPUT
    MOV AH, 1
    INT 21H
    SUB AL, 30H
    MOV BH, AL
    
    
    
    ;ADD TWO NUMBER
    ADD AL, BL
    MOV CL, AL
    
    
    
    ;NEWLINE 
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H
    
    
    
    ;THE SUM OF
    MOV AH, 9
    LEA DX, MSG
    INT 21H
    
    
    ;PRINT 1ST NUMBER
    MOV AH, 2
    MOV DL, BL
    ADD DL, 30H
    INT 21H
    
    
    ;AND MSG
    MOV AH, 9
    LEA DX, AND_MSG
    INT 21H
    
    
    ;PRINT 2ND NUMBER
    MOV AH, 2
    MOV DL, BH
    ADD DL, 30H
    INT 21H
    
    
    ;IS MSG
    MOV AH, 9
    LEA DX, IS_MSG
    INT 21H
    
    
    ;PRINT ANSWER
    MOV AH, 2
    MOV DL, CL
    ADD DL, 30H
    INT 21H
    
    
    MOV AX, 4C00H 
    INT 21H                       
MAIN ENDP
END MAIN
