.MODEL SMALL
.STACK 100H
.DATA

e DB 'ENTER A NUMBER: $'
p DB 10, 13, 'POSITIVE$'
q DB 10, 13, 'NEGATIVE$'
i DB 10, 13, 'INVALID NUMBER$'

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    
    MOV AH, 9
    LEA DX, e
    INT 21H  
    
    
    
    MOV AH, 1
    INT 21H
    MOV BL, AL
    
    
    
    CMP BL, 30H
    JG POS
    JL NEGA
    
    POS:
    CMP BL, 39H
    JG INV
    MOV AH, 9
    LEA DX, P
    INT 21H
    JMP EXIT
    
    
    NEGA:
    MOV AH, 1
    INT 21  
    MOV BH, AL
    
    CMP BH, 30H
    JL INV
    CMP BH, 39H
    JG INV
    
    
    MOV AH, 9
    LEA DX, q
    INT 21H
    JMP EXIT
    
    
    INV:
    MOV AH, 9
    LEA DX, i
    INT 21H
    
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN