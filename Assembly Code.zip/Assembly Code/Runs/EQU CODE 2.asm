.MODEL SMALL
.STACK 100H
.DATA
LF EQU 0AH
CR EQU 0DH
MSG DB 'HELLO NIGGA$'
NEWLINE DB LF, CR, '$'

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AH, 9
    LEA DX, MSG
    INT 21H
    
    
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
            
        
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
            
    
    MOV AH, 9
    LEA DX, MSG
    INT 21H
    
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN