.MODEL SMALL
.STACK 100H
.DATA

MSG1 DB 'THE SUM OF $'
AND_MSG DB ' AND $'
ISMSG DB ' IS $'
NEWLINE DB 0AH, 0DH, '$'

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    
    ;PRINT ?
    MOV AH, 2
    MOV DL, '?'
    INT 21H
    
    
    ;TAKE 1ST INPUT
    MOV AH, 1
    INT 21H
    SUB AL, 30H
    MOV BL, AL
    
    
    ;TAKE 2ND INPUT 
    MOV AH, 1
    INT 21H
    SUB AL, 30H
    MOV BH, AL
    
    
    ;SUM
    ADD AL, BL
    MOV CL, AL
    
    
    ;NEWLINE 
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
    
    
        
    ;THE SUM OF
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    
    
    ;PRINT 1ST NUMBER
    MOV AH, 2
    MOV DL, BL
    ADD DL, 30H
    INT 21H
    
    
    
    ;AND MSG
    MOV AH, 9
    LEA DX, AND_MSG
    INT 21H
    
    
    
    ;PRINT 2ND NUMBER
    MOV AH, 2
    MOV DL, BH
    ADD DL, 30H
    INT 21H
    
    
    ;IS MSG
    MOV AH, 9
    LEA DX, ISMSG
    INT 21H
    
    
    
    ;SUM PRINT
    MOV AH, 2
    MOV DL, CL
    ADD DL, 30H
    INT 21H
    
    
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN