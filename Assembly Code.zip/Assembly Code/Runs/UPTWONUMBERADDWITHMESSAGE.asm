.MODEL SMALL
.STACK 100H
.DATA
NEWLINE DB 0AH,0DH,'$'
SUMMSG DB "THE SUM OF $"
ANDMSG DB " AND $"
ISMSG DB " IS $"
A DB ?
B DB ?

.CODE
MAIN PROC
    MOV AX,@DATA
    MOV DS,AX
    
    ;print ? mark
    MOV AH,2
    MOV DL,'?'
    INT 21H
    
    
    ;input
    MOV AH,1
    INT 21H
    MOV BL,AL
    MOV A,BL
    
    
    ;input
    MOV AH,1
    INT 21H
    MOV CL,AL
    MOV B,CL
    
    
    ;newline
    MOV AH,9
    LEA DX,NEWLINE
    INT 21H
            
            
            
    ;print 'the sum of'        
    MOV AH,9
    LEA DX,SUMMSG
    INT 21H 
    
    
    
    ;add
    ADD BL,CL
    SUB BL,30H
    
    
    ;print 1st number
    MOV AH,2
    MOV DL,A
    INT 21H
   
    
    ;print and message
    MOV AH,9
    LEA DX,ANDMSG
    INT 21H
    
    
    ;print 2nd number
    MOV AH,2
    MOV DL,B
    INT 21H
    
    
    
    ;print is msg
    MOV AH,9
    LEA DX,ISMSG
    INT 21H
    
    
    
    ;print sum
    MOV AH,2
    MOV DL,BL
    INT 21H
    
    MOV AH,4CH
    INT 21H
    
    MAIN ENDP
END MAIN