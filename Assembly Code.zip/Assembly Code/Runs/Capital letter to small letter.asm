.MODEL SMALL
.STACK 100H
.DATA

MSG1 DB 'ENTER A CAPITAL LETTER: $'
MSG2 DB 'THE SMALL LETTER IS: $'
NEWLINE DB 0AH, 0DH, '$'

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    
    ;SHOW MSG1
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    
    ;TAKE INPUT
    MOV AH, 1
    INT 21H
    MOV BL, AL
    ADD BL, 20H
    
    
    
    ;NEWLINE
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
    
    
    
    ;SHOW SECOND MSG
    MOV AH, 9
    LEA DX, MSG2
    INT 21H
    
    
    ;SHOW OUTPUT
    MOV AH, 2
    MOV DL, BL
    INT 21H
    
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN