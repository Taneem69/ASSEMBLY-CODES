.MODEL SMALL
.STACK 100H
.DATA
;a EQU 0523H

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX   
    
    
    MOV BX, 0FFFAh
    NEG BX 
    
    mov ah, 2
    mov dl, bl
    ADD dl, 30h
    int 21h
    
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN
    
    