.MODEL SMALL
.STACK 100H
.DATA

CR EQU 0DH
LF EQU 0AH
MSG1 DB 'ENTER A LOWER CASE LETTER: $'
MSG2 DB LF, CR, 'IN UPPER CASE IT IS: '
CHAR DB ?, '$'

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    ;PRINT USER PROMPT
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    
    
    ;TAKE INPUT
    MOV AH, 1
    INT 21H
    SUB AL, 20H
    MOV CHAR, AL
    
    
    ;SHOW OUTPUT MSG 
    ;Because the $ is missing after 'IN UPPER CASE IT IS: ', the string print function (MOV AH, 9) does not stop. It keeps reading right into the next variable in memory, which happens to be your CHAR variable, printing it once
    MOV AH, 9
    LEA DX, MSG2
    INT 21H
    
    
    
    ;SHOW OUTPUT
    ;Then, your code explicitly calls MOV AH, 2 to print CHAR a second time.
    MOV AH, 2
    MOV DL, CHAR
    INT 21H
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN