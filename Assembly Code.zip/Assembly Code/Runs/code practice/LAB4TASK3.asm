.MODEL SMALL
.STACK 100H

.DATA
INPUT DB "ENTER NUMBER: $"
POS DB " POSITIVE$"
NEGA DB  " NEGATIVE$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AH, 9
    LEA DX, INPUT
    INT 21H
    
    
    MOV AH, 1
    INT 21H 
    MOV BL, AL
    
    
    CMP BL, "-"
    JE NEGGA 
    
        
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H  
    
    MOV AH, 2
    MOV DL, BL
    INT 21H
    
    
    MOV AH, 9
    LEA DX, POS
    INT 21H    
    
    JMP EXIT
    
    NEGGA:
    MOV AH, 1
    INT 21H 
    MOV BH, AL
    
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H  
    
    MOV AH, 2
    MOV DL, BL
    INT 21H
    MOV DL, BH
    INT 21H 
    
    
    MOV AH, 9
    LEA DX, NEGA
    INT 21H
    
    
    EXIT:
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN