.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    ;MOV AL, 01011100B
    MOV AL, 00011100B ;TO TEST SAL
    
    SHL AL, 1 
    ;SHL AL, 3 
    
    
    ;SAL AL, 1
    
    
    MOV AH, 2
    MOV DL, AL
    INT 21H
    
    exit:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN