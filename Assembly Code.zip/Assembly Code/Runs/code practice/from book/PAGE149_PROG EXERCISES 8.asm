.MODEL SMALL
.STACK 100H

.DATA
MSG1 DB "TYPE ANY CHARACTER: $"
MSG2 DB 0AH, 0DH, "THE ASCHII CODE OF $"
MSG3 DB " IN BINARY IS: $" 
MSG4 DB 0AH, 0DH, "THE NUMBER OF 1 BIT IS: $"
NEWLINE DB 0AH, 0DH, "$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    
    ;INPUT
    
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    MOV AH, 1
    INT 21H
    MOV BL, AL
    
    
    ;OUTPUT
 
        
    MOV AH, 9
    LEA DX, MSG2
    INT 21H
    
    MOV AH, 2
    MOV DL, BL
    INT 21H

    
        
    MOV AH, 9
    LEA DX, MSG3
    INT 21H
    
    ;BINARY CONVERSION
    MOV CX, 8
    
    BINARY:
    ROL BL, 1
    JC ONE
    
    MOV AH, 2
    MOV DL, "0"
    INT 21H
    JMP CHECK
    
    
    ONE:
    MOV AH, 2
    MOV DL, "1"
    INT 21H

    
    CHECK:
    LOOP BINARY
    
    MOV BH, 0H
            
    MOV AH, 9
    LEA DX, MSG4
    INT 21H
           
           
    MOV CX, 8
    COUNT:
    ROL BL, 1
    JC INCREMENT
    
    JMP REPEAT
    
    
    
    INCREMENT:
    INC BH
    
    REPEAT:
    LOOP COUNT

    
    MOV AH, 2
    MOV DL, BH 
    ADD DL, 30H
    INT 21H 
    
    
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN