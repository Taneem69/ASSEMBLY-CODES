.MODEL SMALL
.STACK 100H

.DATA
MSG1 DB 0AH, 0DH, "TYPE A CHARACTER: $"
MSG2 DB 0AH, 0DH, "THE ASCII CODE OF $"
NEWLINE DB 0AH, 0DH, "$"
MSG3 DB " IS : $"
 


.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    START:
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
  
    MOV AH, 1
    INT 21H 
    CMP AL, 0DH
    JE EXIT
    
    MOV BL, AL
    
    MOV AH, 9
    LEA DX, MSG2
    INT 21H
    
    MOV AH, 2
    MOV DL, BL
    INT 21H 
    
    
    
    MOV AH, 9
    LEA DX, MSG3
    INT 21H
    
     
    
    
    MOV CX, 2
    PRINT:
    MOV DL, BL
    SHR DL, 4
    ROL BL, 4           
    
    
    CMP DL, 10
    JGE CHAR
    MOV AH, 2
    ADD DL, 30H
    INT 21H
    JMP CHECK
    
    CHAR:
    MOV AH, 2
    ADD DL, 55
    INT 21H
    
    
    CHECK:
    LOOP PRINT
    
    JMP START
    

    
    
    
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN