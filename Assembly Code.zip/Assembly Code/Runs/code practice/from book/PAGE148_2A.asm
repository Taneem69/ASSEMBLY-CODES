.MODEL SMALL
.STACK 100H

.DATA
MSG1 DB 0AH, 0DH, "GIVE INPUT: $"
MSG2 DB 0AH, 0DH, "OUTPUT: $"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    
    MOV BL, 01101100B
    
    AND BL, 10101010B
    
    
    
    
    
    
    
    
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN