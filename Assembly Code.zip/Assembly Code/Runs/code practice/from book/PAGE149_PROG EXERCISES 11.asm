.MODEL SMALL
.STACK 100H

.DATA
MSG1 DB 0AH, 0DH, "TYPE A BINARY NUMBER UPTO 16 DIGITS: $"
MSG2 DB 0AH, 0DH, "IN HEX IT IS: $"
NEWLINE DB 0AH, 0DH, "$"
MSG3 DB 0AH, 0DH, "INVALID CHARACTER$" 
MSG4 DB 0AH, 0DH, "YOU CAN TYPE UPTO 16 DIGIT$"
MSG5 DB 0AH, 0DH, "IN HEX IT IS: 0000$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    
    MOV BX, 0
    
    START:
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    

    MOV CX, 0
    
    INPUT:
    CMP CX, 16
    JG BIG
    
       
    MOV AH, 1
    INT 21H
    CMP AL, 0DH
    JE GETOUT
    CMP AL, 30H
    JL ERROR
    CMP AL, 31H
    JG ERROR
    
    
    SHL BX, 1
    SUB AL, 30H
    OR BL, AL
    
    INC CX
    
    JMP INPUT
    
    
    
    ;OUTPUT 
    GETOUT: 
    
    TEST BX, 0FFFFH
    JZ ALLZERO
    JMP PRINT
    
    ALLZERO:
    MOV AH, 9
    LEA DX, MSG5
    INT 21H
    JMP EXIT
    
    PRINT:
    MOV AH, 9
    LEA DX, MSG2
    INT 21H 
    
    
    
    MOV DH, 0
    
    MOV CX, 4
    OUTPUT:
    
    MOV DL, BH
    SHR DL, 4
    ROL BX, 4
    
    CMP DH, 1
    JE PRINTING
    
    CMP DL, 0
    JE CHECK
    
    MOV DH, 1
    
    
    PRINTING:
    CMP DL, 10
    JGE PRINTLETTER
    

    
    MOV AH, 2
    ADD DL, 30H
    INT 21H
    JMP CHECK
    
    
    PRINTLETTER:
    MOV AH, 2
    ADD DL, 55
    INT 21H
    
    CHECK:
    LOOP OUTPUT
    
    JMP EXIT
    
    
    ERROR:
    MOV AH, 9
    LEA DX, MSG3
    INT 21H 
    JMP START
    
    
    BIG:
    MOV AH, 9
    LEA DX, MSG4
    INT 21H
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN