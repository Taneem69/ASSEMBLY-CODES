.MODEL SMALL
.STACK 100H

.DATA
MSG1 DB 0AH, 0DH, "TYPE A BINARY NUMBER UPTO 8 DIGITS: $"
MSG2 DB 0AH, 0DH, "THE BINARY SUM IS: $"
NEWLINE DB 0AH, 0DH, "$"
MSG3 DB 0AH, 0DH, "INVALID CHARACTER$"
MSG4 DB 0AH, 0DH, "TO BIG$"  


.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    START:
    
    ;INPUT 1
    MOV CX, 0
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    
    INPUT1:
    CMP CX, 8
    JG BIG
    
    MOV AH, 1
    INT 21H  
    
    CMP AL, 0DH
    JE SECONDINPUT
    CMP AL, 30H
    JL ERROR
    CMP AL, 31H
    JG ERROR
    
    
    SUB AL, 30H
    SHL BH, 1
    OR BH, AL
    INC CX
    JMP INPUT1  
    
    
    ;INPUT 2
    SECONDINPUT:
    MOV CX, 0
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    
    INPUT2:
    CMP CX, 8
    JG BIG
    
    MOV AH, 1
    INT 21H  
    
    CMP AL, 0DH
    JE GETOUT
    CMP AL, 30H
    JL ERROR
    CMP AL, 31H
    JG ERROR
    
    
    SUB AL, 30H
    SHL BL, 1
    OR BL, AL
    INC CX
    JMP INPUT2
    
    
    
    GETOUT:
    MOV AH, 9
    LEA DX, MSG2
    INT 21H
    
    XOR AX, AX
    XOR DX, DX
    
    MOV AL, BL
    MOV DL, BH
    
    ADD AX, DX
    MOV BX, AX
    SHL BX, 7
    MOV DH, 0
    
    MOV CX, 9
    PRINT:
    SHL BX, 1
    JC ONE
    
    CMP DH, 1
    JE PRINTZERO
    MOV DH, 1
    JMP CHECK
    
    PRINTZERO:
    MOV AH, 2
    MOV DL, "0"
    INT 21H   
    JMP CHECK
    
    ONE:
    MOV AH, 2
    MOV DL, "1"
    INT 21H
    MOV DH, 1 
    
    CHECK:
    LOOP PRINT
    
    
    
    JMP EXIT
    
    
    BIG:
    MOV AH, 9
    LEA DX, MSG4
    INT 21H
    JMP START
    
    
    ERROR: 
    MOV AH, 9
    LEA DX, MSG3
    INT 21H
    JMP START
    
    
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN