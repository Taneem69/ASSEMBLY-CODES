.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AL, 10111001b
    
    XOR AL, AL
    
    
    MOV AH, 2
    MOV DL, AL
    INT 21H
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN