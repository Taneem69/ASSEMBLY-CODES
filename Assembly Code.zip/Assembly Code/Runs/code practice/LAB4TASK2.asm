.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "HELLO WORLD$"  
BYE DB 0AH, 0DH, "BYE WORLD$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX   
    
    MOV CX, 1  
    MOV AH, 9
    LEA DX, MSG
    
    REPEAT:
        CMP CX, 5
        JG EXIT
        
        
        INT 21H
        
        
        INC CX
        JMP REPEAT 
    
    
    EXIT:
    MOV AH, 9
    LEA DX, BYE
    INT 21H
    
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN