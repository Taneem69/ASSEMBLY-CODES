.MODEL SMALL
.STACK 100H

.DATA
MSG1 DB 0AH, 0DH, "GIVE INPUT: $"
MSG2 DB 0AH, 0DH, "OUTPUT: $"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    MOV CX, 8
    
    INPUT:
    MOV AH, 1
    INT 21H
    SUB AL, 30H
    
    
    SHL BL, 1
    OR BL, AL
    
    
    LOOP INPUT
    
    
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H
    
    
    MOV AH, 9
    LEA DX, MSG2
    INT 21H
    MOV CX, 8
    
    PRINT:
    ROL BL, 1 
    ; OR WE CAN DO SHL BL, 1
    JC PRINT1
    MOV AH, 2
    MOV DL, "0"
    INT 21H
    JMP CHECK
    
    
    PRINT1:
    MOV AH, 2
    MOV DL, "1"
    INT 21H
    
    
    
    CHECK:
    LOOP PRINT
    
    
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN