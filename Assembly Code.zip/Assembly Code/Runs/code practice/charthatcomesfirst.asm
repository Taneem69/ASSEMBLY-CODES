.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "Enter character: $"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    
    mov ah, 9
    lea dx, MSG
    int 21h
    
    mov ah, 1
    int 21h
    mov bl, al
              
    mov ah, 9
    lea dx, MSG
    int 21h
    
    mov ah, 1
    int 21h
    mov bh, al
    
    
    
    cmp bl, bh
    jg prev  
    ;xchg bl, bh
    
    mov ah, 2
    mov dl, bl
    int 21h
    mov dl, bh
    int 21h 
    jmp exit
    
    
    
    prev:
     
    mov ah, 2
    mov dl, bh
    int 21h
    mov dl, bl
    int 21h
    
    
    
    exit:        
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN