.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    COMMENT*
    ;EVEN ODD
    
    MOV AL, 01110111B
    
    TEST AL, 00000001B
    JZ EVEN
    JMP ODD
    
    EVEN:
    MOV AH, 2
    MOV DL, "E"
    INT 21H
    JMP EXIT
    
    
    ODD:
    MOV AH, 2
    MOV DL, "O"
    INT 21H *
    
 
    ;SMALL CAP
    MOV AL, "s"
    
    TEST AL, 00100000B
    JZ CAP
    JMP SMA
    
    CAP:
    MOV AH, 2
    MOV DL, "C"
    INT 21H
    JMP EXIT
    
    
    SMA:
    MOV AH, 2
    MOV DL, "S"
    INT 21H 
    
    
  
    
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN