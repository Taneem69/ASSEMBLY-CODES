.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AL, 2H
    MOV BL, 1H
    
    
    CMP AL, BL
    JNBE REV
    MOV AH, 2
    MOV DL, AL
    INT 21H
    JMP exit
    
    REV:
    MOV AH, 2
    MOV DL, BL
    INT 21H

    
    exit:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN