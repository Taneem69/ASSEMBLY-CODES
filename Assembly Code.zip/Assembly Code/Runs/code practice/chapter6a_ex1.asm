.MODEL SMALL
.STACK 100H
.DATA
    ; No data strings needed for register-only manipulation
.CODE
MAIN PROC
    ; Initialize AX with a negative sample number (-5 is 0FFFBh)
    ; (If AX is already positive, it will remain unchanged)
    MOV AX, -15          

    ; 1. Compare the value in AX with 0 using normal CMP
    CMP AX, 0           
    
    ; 2. If AX is greater than or equal to 0, it is already absolute.
    ; We skip the inversion entirely.
    JGE EXIT_ABS        

INVERT_NEG:
    ; 3. If AX < 0, this line executes. 
    ; NEG negates the signed number, turning -5 into +5.
    NEG AX              

EXIT_ABS:
    ; At this point, AX is guaranteed to hold its absolute value (5 or 0005h)

    MOV AH, 4CH         ; Cleanly terminate program execution
    INT 21H
MAIN ENDP
END MAIN
