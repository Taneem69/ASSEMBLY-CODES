.MODEL SMALL
.STACK 100H

.DATA
MSG1 DB 0AH, 0DH, "GIVE INPUT: $"
MSG2 DB 0AH, 0DH, "OUTPUT: $"


.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    MOV BX, 0
    MOV CX, 4
    INPUT:
    MOV AH, 1
    INT 21H
    
    CMP AL, 41H
    JL NUMBER
    CMP AL, 46H
    JG NUMBER
    
    LETTER:
    SUB AL, 37H
    SHL BX, 4
    OR BL, AL
    JMP CHECK
    
    
    NUMBER:
    CMP AL, 30H
    JL ERROR
    CMP AL, 39H
    JG ERROR 
    
    SUB AL, 30H
    SHL BX, 4
    OR BL, AL
    JMP CHECK
    
    
    CHECK:
    LOOP INPUT
    
    
    
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H
    
    
    
    ;OUTPUT   
    MOV AH, 9
    LEA DX, MSG2
    INT 21H
    
    MOV CX, 4
    
    PRINT:
    MOV DL, BH
    SHR DL, 4
    ROL BX, 4
    
    
    CMP DL, 10
    JGE PRINTLETTER
    
    MOV AH, 2
    ADD DL, 48
    INT 21H
    JMP CHECKP    
    
    
    PRINTLETTER:
    MOV AH, 2
    ADD DL, 55
    INT 21H
    
    
    CHECKP:
    LOOP PRINT
     
    
    
    
    ERROR:
    JMP EXIT
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN