.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AX, -5
    
    CMP AX, 0
    JG POS
    JL NEGA
    JE EQL
    
    
    POS:
    MOV BX, 1
    JMP exit
    
    NEGA:
    MOV BX, -1
    JMP exit
    
    
    EQL:
    MOV BX, 0
    JMP exit
    
    exit:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN