.MODEL SMALL
.STACK 100H

.DATA
MSG1 DB 0AH, 0DH, "GIVE INPUT(BIN VALUE): $"
MSG2 DB 0AH, 0DH, "OUTPUT(HEX VALUE): $"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    MOV BX, 0
    MOV CX, 16
    INPUT:
    MOV AH, 1
    INT 21H
    SUB AL, 30H
    SHL BX, 1
    OR BL, AL
    LOOP INPUT
    
    
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H
    
    
    MOV AH, 9
    LEA DX, MSG2
    INT 21H
    
    MOV CX, 4
    OUTPUT:
    MOV DL, BH
    SHR DL, 4
    ROL BX, 4
    
    CMP DL, 10
    JGE PRINTLETTER
    MOV AH, 2
    ADD DL, 30H
    INT 21H
    JMP CHECK
    
    
    
    PRINTLETTER:
    MOV AH, 2
    ADD DL, 55
    INT 21H
    
    
    CHECK:
    LOOP OUTPUT
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN