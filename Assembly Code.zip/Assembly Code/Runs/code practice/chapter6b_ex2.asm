.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AL, "y"
    
    CMP AL, "Y"
    JE PRINT
    CMP AL, "y"
    JE PRINT
    JMP EXIT  
    
    
    PRINT:
    MOV AH, 2
    MOV DL, AL
    INT 21H
    
    exit:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN