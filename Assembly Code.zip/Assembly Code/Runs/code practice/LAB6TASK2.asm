.MODEL SMALL
.STACK 100H
.DATA

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    MOV BX, 1  
    MOV DX, 0
    
    MOV CX, 50
    
    REPEAT:
    ADD DX, BX
    
    ADD BX, 4     
    LOOP REPEAT

        
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN