.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV CX, 0 
    JCXZ exit
    PRINT:
    MOV AH, 2
    MOV DL, "*"
    INT 21H
    

    LOOP PRINT
    
    exit:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN