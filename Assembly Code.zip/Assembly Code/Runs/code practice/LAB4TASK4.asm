.MODEL SMALL
.STACK 100H

.DATA

G DB 0AH, 0DH, "GREATER THAN 5$"
E DB 0AH, 0DH, "EQUAL TO 5$"
L DB 0AH, 0DH, "LESS THAN 5$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AH, 1
    INT 21H
    MOV BL, AL
    SUB BL, 30H
    
    
    CMP BL, 5
    JG GG
    JE EE
    JL LL
    
    GG:
    MOV AH, 9
    LEA DX, G
    INT 21H
    JMP EXIT
    
    EE:
    MOV AH, 9
    LEA DX, E
    INT 21H
    JMP EXIT 
    
    
    LL:
    MOV AH, 9
    LEA DX, L
    INT 21H
    JMP EXIT
     
    EXIT: 
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN