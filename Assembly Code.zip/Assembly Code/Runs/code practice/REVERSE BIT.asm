.MODEL SMALL
.STACK 100H
.DATA  
MSG1 DB 0AH, 0DH, "GIVE INPUT: $"
MSG2 DB 0AH, 0DH, "OUTPUT: $"
MSG3 DB 0AH, 0DH, "REVERSE OUTPUT: $"

.CODE
MAIN PROC
MOV AX, @DATA
    MOV DS, AX 
    
    
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    MOV CX, 8
    
    INPUT:
    MOV AH, 1
    INT 21H
    SUB AL, 30H
    
    
    SHL BL, 1
    OR BL, AL
    
    
    LOOP INPUT
    
    
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H
    
    
    
    MOV AH, 9
    LEA DX, MSG2
    INT 21H
    MOV CX, 8 
    
    PRINT1:
    ROL BL, 1
    JC ONE1
    MOV AH, 2
    MOV DL, "0"
    INT 21H   
    JMP CHECK1
    
    
    ONE1:
    MOV AH, 2
    MOV DL, "1"
    INT 21H
    
    CHECK1:
    LOOP PRINT1 
    
    
    
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H
    
    MOV CX, 8
    
    ;ROTATE
    MOV CX, 8
    ROT:
    ROR BL, 1 ;or SHR BL, 1
    RCL BH, 1
    LOOP ROT
    
    
    MOV AH, 9
    LEA DX, MSG3
    INT 21H
    MOV CX, 8 
    
    PRINT:
    ROL BH, 1  ;or SHL BL, 1
    JC ONE
    MOV AH, 2
    MOV DL, "0"
    INT 21H   
    JMP CHECK
    
    
    ONE:
    MOV AH, 2
    MOV DL, "1"
    INT 21H
    
    CHECK:
    LOOP PRINT  
    
    
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
    END MAIN