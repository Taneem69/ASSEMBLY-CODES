.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV BL, 41H
    MOV CX, 26
    
    
    PRINT:
    MOV AH, 2
    MOV DL, BL
    INT 21H
    INC BL
    LOOP PRINT
    
    
    exit:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN