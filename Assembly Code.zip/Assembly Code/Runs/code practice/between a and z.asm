.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    mov ah, 1
    int 21h 
    mov bl, al
    
    cmp bl, "A"
    jl HH 
    cmp bl, "Z"
    jg HH
    
    mov ah, 2
    mov dl, bl
    int 21h  
    JMP exit
    
    
    HH:
    MOV AH, 9
    LEA DX, MSG
    INT 21H
    
    exit:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN