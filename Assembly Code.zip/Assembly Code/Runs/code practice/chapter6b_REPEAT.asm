.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga:$" 
MSG2 DB 0AH, 0DH, "TOTAL COUNT: $"   
NEWLINE DB 0AH, 0DH, "$"


.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AH, 1

    
    REPEAT:
    INT 21H
    CMP AL, " "
    JNE REPEAT
    
    
    exit: 
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN