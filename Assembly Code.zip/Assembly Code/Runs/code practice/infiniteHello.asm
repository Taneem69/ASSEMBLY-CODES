.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "HELLO WORLD$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AH, 9       
    LEA DX, MSG
    REPEAT:
       
       INT 21H
       
       JMP REPEAT 
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN


