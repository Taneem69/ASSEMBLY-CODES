.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV AL, "5"
    
    ;AND AL, 0FH  ;CHAR TO NUMBER
    
    ;OR AL, 30H   ;NUMBER TO CHAR
    
    
    MOV AH, 2
    MOV DL, AL
    INT 21H
    
    exit:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN