.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga:$" 
MSG2 DB 0AH, 0DH, "TOTAL COUNT: $"   
NEWLINE DB 0AH, 0DH, "$"


.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV BL, 0H
    
    MOV AH, 9
    LEA DX, MSG
    INT 21H 
    
    
    MOV AH, 1
    INT 21H
    
    WHILE_:
    CMP AL, 0DH
    JE exit
    INC BL
    INT 21H
    
    JMP WHILE_
    
    
    
    
    
    
    
    exit: 
    
    MOV AH, 9
    LEA DX, MSG2
    INT 21H  
    
    MOV AH, 2
    MOV DL, BL
    ADD DL, 30H
    INT 21H
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN