.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "ENTER A CHARACTER: $"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    MOV AH, 9
    LEA DX, MSG
    INT 21H
    
    MOV AH, 1
    INT 21H
    MOV BL, AL
               
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H
    
    ;MOV CX, 10
    
    ;REPEAT:
    ;MOV AH, 2
    ;MOV DL, BL
    ;INT 21H
    ;LOOP REPEAT 
    
    
    
    MOV CX, 50
    
    REPEAT:
        CMP CX, 0
        JNZ PRINT
        JMP  EXIT
        
        
    PRINT:
        MOV AH, 2
        MOV DL, BL
        INT 21H
        DEC CX
        JMP REPEAT
    
    
    EXIT:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN