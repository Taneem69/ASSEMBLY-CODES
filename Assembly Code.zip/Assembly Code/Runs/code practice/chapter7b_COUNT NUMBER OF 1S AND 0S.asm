.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    ;MOV BX, 10011010B     
    MOV CX, 8
    INPUT:
    MOV AH, 1
    INT 21H
    SUB AL, 30H
    SHL BL, 1
    OR BL, AL
    LOOP INPUT
    
    MOV AL, 0
    MOV BH, 0
    
    
    MOV CX, 8
REPEAT_LOOP:
    ROL BL, 1   
    JC ONE       


    INC BH        
    JMP CHECK_LOOP 

ONE:
    INC AL          

CHECK_LOOP:
    LOOP REPEAT_LOOP 
    
    
    EXIT:  
    MOV AH, 2
    MOV DL, AL
    ADD DL, 30H
    INT 21H
    MOV DL, BH
    ADD DL, 30H
    INT 21H
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN