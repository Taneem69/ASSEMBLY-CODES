.MODEL SMALL
.STACK 100H
.DATA
    p db 'Enter your password: $'
    m db 10,13,'Password Matched$'
    n db 10,13,'Password Not Matched$'
.CODE
MAIN PROC
    mov ax, @data
    mov ds, ax

    ; 1. Print the prompt
    mov ah, 9
    lea dx, p
    int 21h

    ; 2. Read and verify each letter one-by-one live
    mov ah, 1

    int 21h
    cmp al, 'm'
    jne fail

    int 21h
    cmp al, 'y'
    jne fail

    int 21h
    cmp al, 'p'
    jne fail

    int 21h
    cmp al, 'a'
    jne fail

    int 21h
    cmp al, 's'
    jne fail

    int 21h
    cmp al, 's'
    jne fail

    int 21h
    cmp al, 'w'
    jne fail

    int 21h
    cmp al, 'o'
    jne fail

    int 21h
    cmp al, 'r'
    jne fail

    int 21h
    cmp al, 'd'
    jne fail

    ; 3. Verify the user pressed 'Enter' at the very end
    int 21h
    cmp al, 13      ; ASCII 13 is the Enter key
    jne fail

match:
    mov ah, 9
    lea dx, m
    int 21h
    jmp exit        ; Unconditional jump to skip the fail block!

fail:
    mov ah, 9
    lea dx, n
    int 21h

exit:
    mov ax, 4c00h
    int 21h
MAIN ENDP
END MAIN
