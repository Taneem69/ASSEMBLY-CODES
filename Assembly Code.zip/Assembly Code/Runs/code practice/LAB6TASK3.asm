.MODEL SMALL
.STACK 100H
.DATA

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    MOV BX, 100  
    MOV DX, 0
    
    MOV CX, 19
    
    REPEAT:
    ADD DX, BX
    
    SUB BX, 5     
    LOOP REPEAT

        
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN