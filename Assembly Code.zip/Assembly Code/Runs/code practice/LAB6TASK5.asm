.MODEL SMALL
.STACK 100H
.DATA
MSG1 DB "ENTER TWO CHARACTER: $"
MSG2 DB "THANK YOU$"
NEWLINE DB 0AH, 0DH, "$"
.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    MOV AH, 9
    LEA DX, MSG1
    INT 21H
    
    MOV AH, 1
    INT 21H
    MOV BL, AL
    INT 21H
    MOV BH, AL
    
    
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
    
    
    CMP BL, BH
    JG REV
    MOV AH, 2
    MOV DL, BL
    INT 21H
    MOV DL, BH
    INT 21H
    JMP EXIT
    
    
    REV:
    MOV AH, 2
    MOV DL, BH
    INT 21H
    MOV DL, BL
    INT 21H
    JMP EXIT

    EXIT: 
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
    MOV AH, 9
    LEA DX, MSG2
    INT 21H    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN