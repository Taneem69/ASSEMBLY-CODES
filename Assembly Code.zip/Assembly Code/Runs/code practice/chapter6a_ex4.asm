.MODEL SMALL
.STACK 100H

.DATA
MSG DB 0AH, 0DH, "nigga$"

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    ;MOV AL, 1 
    ;MOV AL, 3
    MOV AL, 2
    ;MOV AL, 4  
    
    
    CMP AL, 1
    JE PRINTO
    CMP AL, 3
    JE PRINTO
    CMP AL, 2
    JE PRINTE
    CMP AL, 4
    JE PRINTE
    
    
    PRINTO:
    MOV AH, 2
    MOV DL, "O"
    INT 21H
    JMP exit
    
    
    PRINTE:
    MOV AH, 2
    MOV DL, "E"
    INT 21H
    exit:
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN