.MODEL SMALL
.STACK 100H
.DATA

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX 
    
    MOV BL, 0
    
    MOV CX, 255
    
    REPEAT:
    MOV AH, 2
    MOV DL, BL
    INT 21H
            
    INC BL       
    LOOP REPEAT
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN