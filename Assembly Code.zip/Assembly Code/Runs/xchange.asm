.MODEL SMALL
.STACK 100H
.DATA
 
C DB ?
D DB ?
NEWLINE DB 0AH, 0DH, '$'
.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    
    ;INPUT 
    MOV AH, 1
    INT 21H
    MOV C, AL
    
    
    ;INPUT 
    MOV AH, 1
    INT 21H
    MOV D, AL
    
    
    ;XCNG    
    MOV BH, C ;BH=1 C=1
    XCHG BH, D;BH=1 D=2 AFTER XCNG BH=2 D=1
    MOV C, BH ;C=2 BH=2
    
    
    ;NEWLINE
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
    
    
    ;NEWLINE
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
    
    
    ;DISPLAY
    MOV AH, 2
    MOV DL, C
    INT 21H
    MOV DL, D
    INT 21H
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN