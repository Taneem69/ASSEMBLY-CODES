.model small
.stack 100h
.data
msg db 0ah,0dh, "Hello, World $"
.code
main proc 
    mov ax, @data
    mov ds, ax
    start: 
        mov ah,9   
        lea dx,msg 
        int 21h      
        jmp start 
                     
    mov ah, 4ch
    main endp
end main
 
