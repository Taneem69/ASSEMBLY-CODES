.MODEL small
.STACK 100h
.DATA
    msg1 db "Equal to 5 $"
    msg2 db "Less than 5 $"
    msg3 db "Greater than 5 $"
.CODE
    MAIN PROC  
        
        mov ax,@DATA
        mov ds,ax
        
        mov ah,01h
        int 21h
        mov bl,al
        sub bl,30h
        
        mov ah,02h
        mov dx,0Dh
        int 21h
        mov dx,0Ah
        int 21h
        
        check:
            cmp bl,5h
                je equal
                jg greater
                jl less
                
        equal:
            mov ah,09h
            lea dx,msg1
            int 21h
            
            jmp end
        
        greater:
            mov ah,09h
            lea dx,msg3
            int 21h
            
            jmp end
        
        less:
            mov ah,09h
            lea dx,msg2
            int 21h
            
            jmp end
            
        end:
            mov ah,4Ch
            int 21h
                
    MAIN ENDP
END MAIN
