.MODEL SMALL
.STACK 100H
.DATA
a EQU 2H
b DB ?
.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV BL, a
    
    MOV AH, 2
    ADD BL, 30H ;Converts the numerical value 2 into its ASCII character equivalent '2'.
    
    MOV DL, BL
    INT 21H
    
    
    MOV AH, 1
    INT 21H
    MOV b, AL ;iNPUT IS SAVED IN AL VARIABLE, THEN MOVED TO b VARIABLE
    
    MOV AH, 2
    MOV DL,b
    INT 21H
    
    MOV CX, 9H
    DEC CX
    
    MOV AH, 2
    MOV DL, CL
    ADD DL, 30H
    INT 21H
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN