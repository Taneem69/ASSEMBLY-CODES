.MODEL SMALL
.STACK 100H
.DATA

A EQU 4

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV BX, A
    DEC BX
    
    
    MOV AH, 2
    MOV DL, BL
    ADD DL, 30H
    INT 21H
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN