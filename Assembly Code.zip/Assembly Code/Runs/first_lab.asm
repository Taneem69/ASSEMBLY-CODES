.MODEL SMALL
.STACK 100H
.DATA

A DB 'HELLO NIGGA$'
B DB 'HELLO$'
NEWLINE DB 0AH, 0DH, '$'
NEW DB 10, 13

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    
    MOV AH, 9
    LEA DX, A
    INT 21H
    
    
    ;MANUALL NEWLINE
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H 
    
    
    MOV AH, 9
    LEA DX, NEWLINE
    INT 21H
    
    
    MOV AH, 9
    LEA DX, B
    INT 21H
    
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN