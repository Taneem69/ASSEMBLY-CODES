.MODEL SMALL
.STACK 100H
.DATA

A EQU 2H
B DB ? 

.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX
    
    MOV BL, A
    
    MOV AH, 2
    ADD BL, 30H
    MOV DL, BL 
    INT 21H  
    
    
    MOV AH, 1
    INT 21H
    MOV BL, AL
    
    
    MOV AH, 2
    MOV DL, 0AH
    INT 21H
    MOV DL, 0DH
    INT 21H 
    
    
    
    MOV AH, 2
    MOV DL, BL
    INT 21H  
    
    
    MOV BX, 9H
    DEC BX
    
    MOV AH, 2
    MOV DL, BL
    ADD DL, 30H
    INT 21H
    
    
    MOV AH, 4CH
    INT 21H
    MAIN ENDP
END MAIN